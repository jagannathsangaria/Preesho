# Preesho Terms & Conditions — Template

These terms govern use of the Preesho shopping application.

Users must provide accurate information and use the service lawfully. Product availability, pricing, delivery, cancellation, refund and return rules should be defined by the business and shown to customers before an order is placed.

Do not publish this template unchanged. Add the business legal name, contact details, applicable jurisdiction, refund/return rules and final operational policies.
