# Preesho Privacy Policy — Template

Effective date: [INSERT DATE]

Preesho may collect account information, delivery information, order information and technical information necessary to provide the shopping service.

Information is used to:
- create and manage accounts
- process and deliver orders
- provide customer support
- improve app reliability and security

Do not publish this template unchanged. Replace placeholders and have the final policy reviewed for the actual services used by the app, including the backend, analytics, notifications and payment provider.
