# Preesho Release Checklist

## App
- [x] Home
- [x] Categories
- [x] Product catalogue
- [x] Search
- [x] Cart
- [x] Address form
- [x] Login/Sign-up UI
- [x] Profile
- [x] Backend abstraction
- [x] Admin/API specification
- [ ] Real production backend credentials
- [ ] Real product catalogue
- [ ] Production authentication
- [ ] Privacy policy URL
- [ ] Terms & conditions
- [ ] Support email/phone
- [ ] App icon/splash artwork
- [ ] Android signing key
- [ ] Play Console app setup
- [ ] AAB build and Play upload
- [ ] Payment gateway (when enabled)

## Important
The source is launch-structured, but no developer can truthfully produce a live Play Store launch without the owner's Google Play Console/account access, signing credentials and production service credentials. These must remain private and should never be embedded in source code.
