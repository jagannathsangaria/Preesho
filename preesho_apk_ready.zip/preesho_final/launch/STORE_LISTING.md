# Preesho — Store Listing

App name: Preesho
Short description: Shop smarter with Preesho.
Full description:
Preesho is a simple, mobile-first shopping application for discovering products, browsing categories, managing a cart, saving delivery addresses and tracking orders.

Key features:
- Browse products and categories
- Search products
- Add and remove products from cart
- Manage delivery address
- Customer login/sign-up interface
- Profile and order sections
- Ready for secure backend integration
- Payment gateway reserved for the production configuration

Privacy:
Replace this section with the final privacy-policy URL before publishing.
